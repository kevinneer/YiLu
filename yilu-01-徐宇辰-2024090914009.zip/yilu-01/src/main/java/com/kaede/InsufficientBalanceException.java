package com.kaede;

public class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String message) {
        super(message);
    }

    public static InsufficientBalanceException create(String accountNumber,double amount){
        String message = String.format("账户号码: %s 余额不足。尝试提取金额: %.2f", accountNumber, amount);
        return new InsufficientBalanceException(message);
    }
}
