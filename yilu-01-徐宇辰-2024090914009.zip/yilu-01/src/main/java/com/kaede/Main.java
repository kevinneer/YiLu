package com.kaede;

public class Main {
    public static void main(String[] args) {
        Triangle triangle1 = new Triangle(3.0,4.0,5.0);
        Triangle triangle2 = new Triangle(1.0,2.0,3.0);

        try{
            System.out.println("三角形1的面积："+triangle1.area());
        }catch(NotTriangle e){
            System.out.println("三角形1"+e.getMessage());
        }
        try{
            System.out.println("三角形2的面积："+triangle2.area());
        }catch(NotTriangle e){
            System.out.println("三角形2"+e.getMessage());
        }

    }


}