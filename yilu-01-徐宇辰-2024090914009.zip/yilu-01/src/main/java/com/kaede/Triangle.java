package com.kaede;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Triangle {
    public double a;
    public double b;
    public double c;



    private boolean isTriangle(){
        return a>0&&b>0&&c>0&&
                a+b>c&&
                b+c>a&&
                c+a>b;
    }

    public double area() throws NotTriangle{
        if(!isTriangle()){
            throw new NotTriangle("无法构成三角形");
        }
        double s = (a+b+c)/2;
        return Math.sqrt(s*(s-a)*(s-b)*(s-c));
    }

}

class NotTriangle extends Exception{
    public NotTriangle(String message){
        super(message);
    }
}


