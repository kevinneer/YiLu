package com.kaede;

import com.kaede.shape.Circle;
import com.kaede.shape.PlainRect;
import com.kaede.shape.Square;

public class Main {
    public static void main(String[] args) {
        Perarea square = new Square(10,5);
        Perarea circle = new Circle(5);

        System.out.println("长方形面积: " + square.get_area());
        System.out.println("长方形周长: " + square.get_perimeter());

        System.out.println("圆形面积: " + circle.get_area());
        System.out.println("圆形周长: " + circle.get_perimeter());



        PlainRect rect = new PlainRect(10, 10, 20, 10);

        System.out.println("矩形面积: " + rect.area());
        System.out.println("矩形周长: " + rect.perimeter());

        // 判断点 (25.5, 13) 是否在矩形内
        boolean isInside = rect.isInside(25.5, 13);
        System.out.println("点 (25.5, 13) 是否在矩形内: " + isInside);
    }
}