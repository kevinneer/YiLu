package com.kaede.shape;

public class PlainRect extends Rect {
    private double startX;
    private double startY;

    public PlainRect(double startX, double startY, double width, double height) {
        super(width, height);
        this.startX = startX;
        this.startY = startY;
    }

    public PlainRect(){
        this(0, 0, 0, 0);
    }

    public boolean isInside(double x, double y) {
        return  x >= startX && x <= (startX + width) &&
                y >= startY && y <= (startY + height);
    }
}
