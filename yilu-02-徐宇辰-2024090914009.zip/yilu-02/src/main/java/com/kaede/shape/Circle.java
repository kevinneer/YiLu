package com.kaede.shape;

import com.kaede.Perarea;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Circle implements Perarea {
    private double radius;


    @Override
    public double get_area() {
        return Math.PI * radius * radius;
    }

    @Override
    public double get_perimeter() {
        return 2*Math.PI*radius;
    }
}
