package com.kaede.shape;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Rect {
    protected double width;
    protected double height;

    public Rect() {
        this(10,10);
    }

    public double area(){
        return width*height;
    }

    public double perimeter(){
        return 2*width+2*height;
    }

}


