package com.kaede.shape;

import com.kaede.Perarea;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Square implements Perarea {
    private double length;
    private double width;


    @Override
    public double get_area() {
        return length * width;
    }

    @Override
    public double get_perimeter() {
        return 2*(length+width);
    }
}
