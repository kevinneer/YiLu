package com.kaede;

public interface Perarea {
    double get_area();
    double get_perimeter();
}
